﻿namespace Modelos;
public enum Comunidad
{
    Aragón,
    Madrid,
    Barcelona
}


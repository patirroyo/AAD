﻿using System;
namespace Modelos
{
	public class ComunidadCuantos
	{
		public Comunidad Comunidad{ get; set; }

		public int SuperficieTotal { get; set; }

		public int NumeroHabitantes { get; set; }

        public int NumeroProvincias { get; set; }
    }
}

